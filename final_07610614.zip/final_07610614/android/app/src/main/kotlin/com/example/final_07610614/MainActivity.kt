package com.example.final_07610614

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
