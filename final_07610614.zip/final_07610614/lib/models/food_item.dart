class FoodItem {
  final int id;
  final String team;
  final int group;
  final String flagImage;
  final int voteCount;
  FoodItem({
    required this.id,
    required this.team,
    required this.group,
    required this.flagImage,
    required this.voteCount,
  });

  factory FoodItem.fromJson(Map<String, dynamic> json) {
    return FoodItem(
      id: json['id'],
      team: json['team'],
      group: json['group'],
      flagImage: json['flagImage'],
      voteCount: json['voteCount'],
    );
  }

  // named constructor
  FoodItem.fromJson2(Map<String, dynamic> json)
      : id = json['id'],
        team = json['team'],
        group = json['group'],
        flagImage = json['flagImage'],
        voteCount = json['voteCount'];
}